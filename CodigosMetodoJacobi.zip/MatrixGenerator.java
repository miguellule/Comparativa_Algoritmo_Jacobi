import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class MatrixGenerator {
    public static void main(String[] args) {
        if (args.length > 0) {
            if (args[0] != null) {
                int n = Integer.parseInt(args[0]);
                String fileName = "coeficientMatrix"+n+".txt";
                // Generar la primera m atriz aleatoria
                int[][] coeficientMatrix = generateRandomMatrix(n);
                // Generar la segunda matriz aleatoria
                //int[][] matrixB = generateRandomMatrix(n);

                // Guardar las matrices en archivos
                saveMatrix(coeficientMatrix, fileName);
                //saveMatrix(matrixB, "matrixB.txt");

                System.out.println("Matrices generadas y guardadas correctamente.");
            }
        }
        
    }

    

    // Generar una matriz aleatoria de tamaño nxn
    private static int[][] generateRandomMatrix(int n) {
        Random random = new Random();
        int[][] matrix = new int[n][n+1];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n+1; j++) {
                matrix[i][j] = random.nextInt(5)+1; // Números aleatorios entre 0 y 99
            }
        }
        return matrix;
    }

    // Guardar una matriz en un archivo de texto
    private static void saveMatrix(int[][] matrix, String fileName) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(fileName))) {
            for (int[] row : matrix) {
                for (int num : row) {
                    writer.write(num + " ");
                }
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
