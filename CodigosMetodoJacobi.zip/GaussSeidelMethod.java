
import java.io.*;
import java.util.Arrays;
import java.util.StringTokenizer;

public class GaussSeidelMethod {

  public static final int MAX_ITERATIONS = 100;
  private double[][] M;
  
  public GaussSeidelMethod(double [][] matrix) { M = matrix; }


      /**
     * Carga una matriz desde un archivo de texto.
     *
     * @param fileName El nombre del archivo que contiene la matriz.
     * @return Una matriz bidimensional de tipo double.
     */
    private static double[][] loadMatrix(String fileName) {
      double[][] matrix = null;
      try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
          String line;
          int rowCount = 0;
          // Leer el archivo línea por línea
          while ((line = reader.readLine()) != null) {
              
              String[] values = line.trim().split("\\s+");
              // Si es la primera línea, inicializar la matriz             
              if (matrix == null) {
                  matrix = new double[values.length-1][values.length];
              }
              // Leer los valores y asignarlos a la matriz
              for (int i = 0; i < values.length; i++) {
                  matrix[rowCount][i] = Double.parseDouble(values[i]);
              }

              System.out.println("rowCount: "+rowCount);
              System.out.println("Values.lenght: "+(values.length-2));
              if(rowCount == (values.length-2))
                  break;
              rowCount++;
          }
      } catch (IOException e) {
          e.printStackTrace();
      }
      return matrix;
  }

  public void print()
  {
    int n = M.length;
    for (int i = 0; i < n; i++) {
      for (int j = 0; j < n + 1; j++)
        System.out.print(M[i][j] + " ");
      System.out.println();
    }
  }

  public boolean transformToDominant(int r, boolean[] V, int[] R)
  {
    int n = M.length;
    if (r == M.length) {
      double[][] T = new double[n][n+1];
      for (int i = 0; i < R.length; i++) {
        for (int j = 0; j < n + 1; j++)
          T[i][j] = M[R[i]][j];
      }

      M = T;
      
      return true;
    }

    for (int i = 0; i < n; i++) {
      if (V[i]) continue;

      double sum = 0;
      
      for (int j = 0; j < n; j++)
        sum += Math.abs(M[i][j]);

      if (2 * Math.abs(M[i][r]) > sum) { // diagonally dominant?
        V[i] = true;
        R[r] = i;

        if (transformToDominant(r + 1, V, R))
          return true;

        V[i] = false;
      }
    }

    return false;
  }
  
  public boolean makeDominant()
  {
    boolean[] visited = new boolean[M.length];
    int[] rows = new int[M.length];

    Arrays.fill(visited, false);

    return transformToDominant(0, visited, rows);
  }


  public void GaussSeidelSecuential()
  {
    int iterations = 0;
    int n = M.length;
    double epsilon = 1e-15;
    double[] X = new double[n]; // Approximations
    double[] P = new double[n]; // Prev
    Arrays.fill(X, 0);

    while (true) {
      for (int i = 0; i < n; i++) {
        double sum = M[i][n]; // b_n

        for (int j = 0; j < n; j++)
          if (j != i)
            sum -= M[i][j] * X[j];

        // Update x_i to use in the next row calculation
        X[i] = 1/M[i][i] * sum;   
      }

      System.out.print("X_" + iterations + " = {");
      for (int i = 0; i < n; i++)
        System.out.print(X[i] + " ");
      System.out.println("}");

      iterations++;
      if (iterations == 1) continue;

      boolean stop = true;
      for (int i = 0; i < n && stop; i++)
        if (Math.abs(X[i] - P[i]) > epsilon)
          stop = false;

      if (stop || iterations == MAX_ITERATIONS) break;
      P = (double[])X.clone();
    }
  }

  public void GaussSeidelParallel() throws InterruptedException {
    int iterations = 0;
    int n = M.length;
    double epsilon = 1e-15;
    double[] X = new double[n]; // Approximations
    double[] P = new double[n]; // Prev
    Arrays.fill(X, 0);
  
    while (true) {
      // Create threads for each row update
      Thread[] threads = new Thread[n];
  
      for (int i = 0; i < n; i++) {
        final int row = i; // Avoid race conditions with final keyword
  
        threads[i] = new Thread(() -> {
          double sum = M[row][n]; // b_n
  
          for (int j = 0; j < n; j++) {
            if (j != row) {
              sum -= M[row][j] * X[j];
            }
          }
  
          X[row] = 1 / M[row][row] * sum;
        });
        threads[i].start();
      }
  
      // Wait for all threads to finish
      for (Thread thread : threads) {
        thread.join();
      }
  
      System.out.print("X_" + iterations + " = {");
      for (int i = 0; i < n; i++) {
        System.out.print(X[i] + " ");
      }
      System.out.println("}");
  
      iterations++;
      if (iterations == 1) continue;
  
      boolean stop = true;
      for (int i = 0; i < n && stop; i++) {
        if (Math.abs(X[i] - P[i]) > epsilon) {
          stop = false;
        }
      }
  
      if (stop || iterations == MAX_ITERATIONS) break;
      P = (double[]) X.clone();
    }
  }
  
    public static void generarYGuardarTiempos(int tamanoMatriz, long tiempoParalelo, long tiempoSecuencial, String unidadMedida) {
      if (unidadMedida.equals("ns")) {
          // No es necesario ajustar el tiempo
      } else if (unidadMedida.equals("μs")) {
          tiempoParalelo /= 1000;
          tiempoSecuencial /= 1000;
      } else if (unidadMedida.equals("ms")) {
          tiempoParalelo /= 1000000;
          tiempoSecuencial /= 1000000;
      } else if (unidadMedida.equals("s")) {
          tiempoParalelo /= 1000000000;
          tiempoSecuencial /= 1000000000;
      }
      String nombreArchivo = "resultadosJacobi" + tamanoMatriz + ".txt";

      try {
          FileWriter archivo = new FileWriter(nombreArchivo, true); // Modo append: true
          PrintWriter pw = new PrintWriter(archivo);

          // Verificar si es necesario escribir el tamaño de la matriz
          if (!primeraFilaContieneSoloNumero(nombreArchivo)) {
              pw.println(tamanoMatriz);
          }

          // Escribir tiempos en archivo con unidad de medida
          pw.println(tiempoParalelo + " " + tiempoSecuencial + " " + unidadMedida);

          pw.close();
          archivo.close();
          System.out.println("Tiempos guardados correctamente en " + nombreArchivo);
      } catch (IOException e) {
          System.err.println("Error al guardar los tiempos en el archivo: " + e.getMessage());
      }
  }

  private static boolean primeraFilaContieneSoloNumero(String nombreArchivo) throws IOException {
      try (BufferedReader br = new BufferedReader(new FileReader(nombreArchivo))) {
          String primeraLinea = br.readLine();
          if (primeraLinea == null) {
              return false;
          }
          try {
              Integer.parseInt(primeraLinea.trim());
              return true;
          } catch (NumberFormatException e) {
              return false;
          }
      }
  }
  public static String formatTiempo(long tiempo) {
      if (tiempo < 1000) {
          return "ns";
      } else if (tiempo < 1000000) {
          return "μs";
      } else if (tiempo < 1000000000) {
          return "ms";
      } else {
          return "s";
      }
  }
  public static void main(String[] args) throws IOException
  {
    if (args.length > 0) {
      if (args[0] != null) {
        String fileName = "coeficientMatrix"+args[0]+".txt";
        PrintWriter writer = new PrintWriter(System.out, true);

        // double[][] coefficients = {
        //     {3, -1, -1, 1},
        //     {-1, 3, 1, 3},
        //     {2, 1, 4, 7}
        // };

        double[][] coefficients = loadMatrix(fileName);
        
        GaussSeidelMethod gausSeidel = new GaussSeidelMethod(coefficients);
        GaussSeidelMethod gausSeidel2 = new GaussSeidelMethod(coefficients);
        if (!gausSeidel.makeDominant()) {
          writer.println("The system isn't  diagonally dominant: " + 
                        "The method cannot guarantee convergence.");
        }

        // writer.println();
        // gausSeidel.print();
        long ParallelStartTime = 0;
        long ParallelEndTime = 0;

        try {
          ParallelStartTime = System.nanoTime();
          gausSeidel.GaussSeidelParallel();
          ParallelEndTime = System.nanoTime();
        } catch (InterruptedException e) {
          // Handle the interruption appropriately, 
          //  e.g., print an error message, retry the operation, etc.
          System.err.println("GaussSeidelParallel was interrupted!");
        }
      
        long SecuentialStartTime = System.nanoTime();
        gausSeidel2.GaussSeidelSecuential();
        long SecuentialEndTime = System.nanoTime();

        
         // Calculo de los tiempos transcurridos por cada implementacion 
         long ParallelElapsedTime = ParallelEndTime - ParallelStartTime;
         long SecuentialElapsedTime = SecuentialEndTime - SecuentialStartTime;

         // Conversion y muestreo de los tiempos de ejecucion en milisegundos en la terminal
         System.out.println("\nMetodo de jacobi matrices de "+args[0]+" x "+args[0]);
         System.out.println("Paralelo: " + (ParallelElapsedTime/1000000) +" ms ");  
         System.out.println("Secuencial: " + (SecuentialElapsedTime/1000000) +" ms ");
         
         String unidadTiempo = formatTiempo(SecuentialElapsedTime);
         // generarYGuardarTiempos(Integer.parseInt(args[0]), (ParallelElapsedTime/1000), (SecuentialElapsedTime/1000), "μs");   
         generarYGuardarTiempos(Integer.parseInt(args[0]), ParallelElapsedTime, SecuentialElapsedTime, unidadTiempo); 
        
      }
    }
}
}

