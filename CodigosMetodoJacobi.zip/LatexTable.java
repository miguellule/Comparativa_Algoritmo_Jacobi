import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

public class LatexTable {

    public static void main(String[] args) {
        if (args.length != 2) {
            System.err.println("Uso: java GenerarTablaLatex resultados"+args[0]+args[1]+".txt");
            return;
        }

        String nombreArchivo = "resultados"+args[0]+args[1]+".txt";
        
        // Leer datos del archivo
        List<Integer> tamanos = new ArrayList<>();
        List<Long> tiemposParalelo = new ArrayList<>();
        List<Long> tiemposSecuencial = new ArrayList<>();
        List<String> unidadesMedida = new ArrayList<>();
        try {
            BufferedReader br = new BufferedReader(new FileReader(nombreArchivo));
            String linea;
            while ((linea = br.readLine()) != null) {
                if (linea.isEmpty()) continue; // Ignorar líneas vacías
                if (linea.startsWith("//")) continue; // Ignorar comentarios

                String[] datos = linea.split(" ");

                if (datos.length == 1) {
                    // Tamaño del sistema de ecuaciones
                    tamanos.add(Integer.parseInt(datos[0]));
                } else if (datos.length == 3) {
                    // Tiempos de ejecución
                    tiemposParalelo.add(Long.parseLong(datos[0]));
                    System.out.print(Long.parseLong(datos[0])+" ");

                    tiemposSecuencial.add(Long.parseLong(datos[1]));
                    System.out.print(Long.parseLong(datos[1])+" ");

                    unidadesMedida.add(datos[2]);
                    System.out.println(datos[2]);
                }
            }
            br.close();
        } catch (IOException e) {
            System.err.println("Error al leer el archivo: " + e.getMessage());
            return;
        }

        // Generar tabla LaTeX
        generarTablaLatex(tamanos, tiemposParalelo, tiemposSecuencial, unidadesMedida, args[0]);
    }

    public static void generarTablaLatex(List<Integer> tamanos, List<Long> tiemposParalelo, List<Long> tiemposSecuencial, List<String> unidadesMedida, String algoritmo) {
        try {
            FileWriter archivo = new FileWriter("tablaLatex"+tamanos.get(0)+".tex");
            PrintWriter pw = new PrintWriter(archivo);

            // Encabezado de la tabla
            pw.println("\\begin{table}[h]");
            pw.println("\\centering");
            pw.println("\\begin{tabular}{|c|c|c|}");
            pw.println("\\hline");
            pw.println("Paralelo & Secuencial & Unidad de Medida \\\\");
            pw.println("\\hline");
            System.out.println(tiemposParalelo.size());
            // Datos de la tabla
            for (int i = 0; i < tiemposParalelo.size(); i++) {
                // if(unidadesMedida.get(i).equals("μs"))
                //     pw.println(tamanos.get(0) + " & " + tiemposParalelo.get(i) + " & " + tiemposSecuencial.get(i) +" & " + "\\textmu s" + " \\\\");
                // else 
                //     pw.println(tamanos.get(0) + " & " + tiemposParalelo.get(i) + " & " + tiemposSecuencial.get(i) +" & " + unidadesMedida.get(i) + " \\\\");
                
                if(unidadesMedida.get(i).equals("μs"))
                    pw.println(tiemposParalelo.get(i) + " & " + tiemposSecuencial.get(i) +" & " + "\\textmu s" + " \\\\");
                else 
                    pw.println(tiemposParalelo.get(i) + " & " + tiemposSecuencial.get(i) +" & " + unidadesMedida.get(i) + " \\\\");
            }

            // Fin de la tabla
            pw.println("\\hline");
            pw.println("\\end{tabular}");
            pw.println("\\caption{Tabla comparativa del algoritmo "+algoritmo+", paralelo y secuencial en un sistema de "+tamanos.get(0)+" incognitas}");
            pw.println("\\end{table}");


            pw.close();
            archivo.close();
            System.out.println("Tabla generada correctamente en tabla.tex");
        } catch (IOException e) {
            System.err.println("Error al generar la tabla: " + e.getMessage());
        }
    }
}
