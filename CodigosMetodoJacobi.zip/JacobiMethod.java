import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.StringTokenizer;
import java.util.concurrent.*;
import java.io.FileReader;

import java.io.FileWriter;


public class JacobiMethod {

    public static final int MAX_ITERATIONS = 300;
    private double[][] coefficientsMatrix;

    /**
     * Carga una matriz desde un archivo de texto.
     *
     * @param fileName El nombre del archivo que contiene la matriz.
     * @return Una matriz bidimensional de tipo double.
     */
    private static double[][] loadMatrix(String fileName) {
        double[][] matrix = null;
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            int rowCount = 0;
            // Leer el archivo línea por línea
            while ((line = reader.readLine()) != null) {
                
                String[] values = line.trim().split("\\s+");
                // Si es la primera línea, inicializar la matriz             
                if (matrix == null) {
                    matrix = new double[values.length-1][values.length];
                }
                // Leer los valores y asignarlos a la matriz
                for (int i = 0; i < values.length; i++) {
                    matrix[rowCount][i] = Double.parseDouble(values[i]);
                }

                // System.out.println("rowCount: "+rowCount);
                // System.out.println("Values.lenght: "+(values.length-2));
                if(rowCount == (values.length-2))
                    break;
                rowCount++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return matrix;
    }

    public JacobiMethod(double[][] matrix) {
        coefficientsMatrix = matrix;
    }

    public void printMatrix() {
        int rows = coefficientsMatrix.length;
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < rows + 1; j++)
                System.out.print(coefficientsMatrix[i][j] + " ");
            System.out.println();
        }
    }

    public boolean transformToDominant(int row, boolean[] visitedRows, int[] selectedRows) {
        int n = coefficientsMatrix.length;
        if (row == n) {
            double[][] tempMatrix = new double[n][n + 1];
            for (int i = 0; i < selectedRows.length; i++) {
                for (int j = 0; j < n + 1; j++)
                    tempMatrix[i][j] = coefficientsMatrix[selectedRows[i]][j];
            }
            coefficientsMatrix = tempMatrix;
            return true;
        }
        for (int i = 0; i < n; i++) {
            if (visitedRows[i]) continue;
            double sum = 0;
            for (int j = 0; j < n; j++)
                sum += Math.abs(coefficientsMatrix[i][j]);
            if (2 * Math.abs(coefficientsMatrix[i][row]) > sum) {
                visitedRows[i] = true;
                selectedRows[row] = i;
                if (transformToDominant(row + 1, visitedRows, selectedRows))
                    return true;
                visitedRows[i] = false;
            }
        }
        return false;
    }

    public boolean makeDiagonallyDominant() {
        boolean[] visitedRows = new boolean[coefficientsMatrix.length];
        int[] selectedRows = new int[coefficientsMatrix.length];
        Arrays.fill(visitedRows, false);
        return transformToDominant(0, visitedRows, selectedRows);
    }

    public void JacobiSecuentialSolver() {
        int iterations = 0;
        int n = coefficientsMatrix.length;
        double epsilon = 1e-15;
        double[] currentApproximations = new double[n];
        double[] previousApproximations = new double[n];
        Arrays.fill(currentApproximations, 0);
        Arrays.fill(previousApproximations, 0);
        while (true) {
            for (int i = 0; i < n; i++) {
                double sum = coefficientsMatrix[i][n];
                for (int j = 0; j < n; j++)
                    if (j != i)
                        sum -= coefficientsMatrix[i][j] * previousApproximations[j];
                currentApproximations[i] = 1 / coefficientsMatrix[i][i] * sum;
            }
            System.out.print("X_" + iterations + " = {");
            for (int i = 0; i < n; i++)
                System.out.print(currentApproximations[i] + " ");
            System.out.println("}");
            iterations++;
            if (iterations == 1) continue;
            boolean stop = true;
            for (int i = 0; i < n && stop; i++)
                // if (Math.abs(currentApproximations[i] - previousApproximations[i]) > epsilon)
                if (Math.abs(currentApproximations[i] - previousApproximations[i]) < epsilon)
                    stop = false;
            if (stop || iterations == MAX_ITERATIONS) break;
            previousApproximations = Arrays.copyOf(currentApproximations, n);
        }
    }


    //Parallel

    public void JacobiParallelSolver() {
        int iterations = 0;
        int n = coefficientsMatrix.length;
        double epsilon = 1e-15;
        double[] currentApproximations = new double[n];
        double[] previousApproximations = new double[n];
        ExecutorService executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());

        while (true) {
            for (int i = 0; i < n; i++) {
                double sum = coefficientsMatrix[i][n];
                Future<Double> future = executor.submit(new CalculationTask(i, n, coefficientsMatrix, previousApproximations));
                try {
                    sum -= future.get();
                } catch (InterruptedException | ExecutionException e) {
                    e.printStackTrace();
                }
                currentApproximations[i] = 1 / coefficientsMatrix[i][i] * sum;
            }

            System.out.print("X_" + iterations + " = {");
            for (int i = 0; i < n; i++)
                System.out.print(currentApproximations[i] + " ");
            System.out.println("}");

            iterations++;
            if (iterations == 1) continue;
            boolean stop = true;
            for (int i = 0; i < n && stop; i++)
                // if (Math.abs(currentApproximations[i] - previousApproximations[i]) > epsilon)
                if (Math.abs(currentApproximations[i] - previousApproximations[i]) < epsilon)
                    stop = false;
            if (stop || iterations == MAX_ITERATIONS) break;
            previousApproximations = currentApproximations.clone();
        }

        executor.shutdown();
    }

    private static class CalculationTask implements Callable<Double> {
        private final int i;
        private final int n;
        private final double[][] coefficientsMatrix;
        private final double[] previousApproximations;

        CalculationTask(int i, int n, double[][] coefficientsMatrix, double[] previousApproximations) {
            this.i = i;
            this.n = n;
            this.coefficientsMatrix = coefficientsMatrix;
            this.previousApproximations = previousApproximations;
        }

        @Override
        public Double call() {
            double sum = 0;
            for (int j = 0; j < n; j++) {
                if (j != i) {
                    sum += coefficientsMatrix[i][j] * previousApproximations[j];
                }
            }
            return sum;
        }
    }

    // public static void generarYGuardarTiempos(int tamanoMatriz, long tiempoParalelo, long tiempoSecuencial) {
    //     String nombreArchivo = "resultados" + tamanoMatriz + ".txt";

    //     try {
    //         FileWriter archivo = new FileWriter(nombreArchivo, true); // Modo append: true
    //         PrintWriter pw = new PrintWriter(archivo);

    //         // Verificar si es necesario escribir el tamaño de la matriz
    //         if (!primeraFilaContieneSoloNumero(nombreArchivo)) {
    //             pw.println(tamanoMatriz);
    //         }

    //         // Escribir tiempos en archivo
    //         pw.println(tiempoParalelo + " " + tiempoSecuencial);

    //         pw.close();
    //         archivo.close();
    //         System.out.println("Tiempos guardados correctamente en " + nombreArchivo);
    //     } catch (IOException e) {
    //         System.err.println("Error al guardar los tiempos en el archivo: " + e.getMessage());
    //     }
    // }

    // private static boolean primeraFilaContieneSoloNumero(String nombreArchivo) throws IOException {
    //     try (BufferedReader br = new BufferedReader(new FileReader(nombreArchivo))) {
    //         String primeraLinea = br.readLine();
    //         if (primeraLinea == null) {
    //             return false;
    //         }
    //         try {
    //             Integer.parseInt(primeraLinea.trim());
    //             return true;
    //         } catch (NumberFormatException e) {
    //             return false;
    //         }
    //     }
    // }
    public static void generarYGuardarTiempos(int tamanoMatriz, long tiempoParalelo, long tiempoSecuencial, String unidadMedida) {
        if (unidadMedida.equals("ns")) {
            // No es necesario ajustar el tiempo
        } else if (unidadMedida.equals("μs")) {
            tiempoParalelo /= 1000;
            tiempoSecuencial /= 1000;
        } else if (unidadMedida.equals("ms")) {
            tiempoParalelo /= 1000000;
            tiempoSecuencial /= 1000000;
        } else if (unidadMedida.equals("s")) {
            tiempoParalelo /= 1000000000;
            tiempoSecuencial /= 1000000000;
        }
        String nombreArchivo = "resultadosJacobi" + tamanoMatriz + ".txt";

        try {
            FileWriter archivo = new FileWriter(nombreArchivo, true); // Modo append: true
            PrintWriter pw = new PrintWriter(archivo);

            // Verificar si es necesario escribir el tamaño de la matriz
            if (!primeraFilaContieneSoloNumero(nombreArchivo)) {
                pw.println(tamanoMatriz);
            }

            // Escribir tiempos en archivo con unidad de medida
            pw.println(tiempoParalelo + " " + tiempoSecuencial + " " + unidadMedida);

            pw.close();
            archivo.close();
            System.out.println("Tiempos guardados correctamente en " + nombreArchivo);
        } catch (IOException e) {
            System.err.println("Error al guardar los tiempos en el archivo: " + e.getMessage());
        }
    }

    private static boolean primeraFilaContieneSoloNumero(String nombreArchivo) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(nombreArchivo))) {
            String primeraLinea = br.readLine();
            if (primeraLinea == null) {
                return false;
            }
            try {
                Integer.parseInt(primeraLinea.trim());
                return true;
            } catch (NumberFormatException e) {
                return false;
            }
        }
    }
    public static String formatTiempo(long tiempo) {
        if (tiempo < 1000) {
            return "ns";
        } else if (tiempo < 1000000) {
            return "μs";
        } else if (tiempo < 1000000000) {
            return "ms";
        } else {
            return "s";
        }
    }
    
    public static void main(String[] args) throws IOException {
        
        if (args.length > 0) {
            if (args[0] != null) {
                String fileName = "coeficientMatrix"+args[0]+".txt";
                PrintWriter writer = new PrintWriter(System.out, true);

                double[][] coefficients = loadMatrix(fileName);
                

                JacobiMethod jacobiSolver = new JacobiMethod(coefficients);

                if (!jacobiSolver.makeDiagonallyDominant()) {
                    writer.println("La matriz no es diagonalmente dominante: " +
                            "El método no puede garantizar la convergencia.");
                }

                //jacobiSolver.printMatrix();

                //System.out.println("\n Implementacion paralela\n");
                long ParallelStartTime = System.nanoTime();
                jacobiSolver.JacobiParallelSolver();
                long ParallelEndTime = System.nanoTime();

                JacobiMethod jacobiSolver2 = new JacobiMethod(coefficients);

                //Medicion del tiempo utilizado por el algoritmo secuencial
                // System.out.println("\n Implementacion secuencial\n");
                
                long SecuentialStartTime = System.nanoTime();
                jacobiSolver2.JacobiSecuentialSolver();
                long SecuentialEndTime = System.nanoTime();

                // Calculo de los tiempos transcurridos por cada implementacion 
                long ParallelElapsedTime = ParallelEndTime - ParallelStartTime;
                long SecuentialElapsedTime = SecuentialEndTime - SecuentialStartTime;

                // Conversion y muestreo de los tiempos de ejecucion en milisegundos en la terminal
                System.out.println("\nMetodo de jacobi matrices de "+args[0]+" x "+args[0]);
                System.out.println("Paralelo: " + (ParallelElapsedTime/1000000) +" ms ");  
                System.out.println("Secuencial: " + (SecuentialElapsedTime/1000000) +" ms ");
                
                String unidadTiempo = formatTiempo(SecuentialElapsedTime);
                // generarYGuardarTiempos(Integer.parseInt(args[0]), (ParallelElapsedTime/1000), (SecuentialElapsedTime/1000), "μs");   
                generarYGuardarTiempos(Integer.parseInt(args[0]), ParallelElapsedTime, SecuentialElapsedTime, unidadTiempo); 
               
            }
        } else {
            System.out.println("No se parason argumentos");
        }
        
        
    }
}
